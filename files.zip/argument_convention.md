# ICM Exchange: Argument-Passing Convention

## Why this document exists

Every Ruby script run via `IExchange`/`ICMExchange.exe` receives its arguments as
`ARGV` -- a flat list of strings, with no names attached. Python builds that list;
Ruby unpacks it positionally. **Both sides have to agree on the order by
convention alone** -- nothing in the language enforces it. Two real bugs in this
project so far have come from exactly this: the two sides silently disagreeing
about order. This doc exists so the next one doesn't happen.

## The rules

1. **Fixed positions, always.** A given script always takes the same *number*
   of arguments, every time it's called. No optional/skippable arguments --
   if a value doesn't apply, send an explicit placeholder (`""`) rather than
   omitting it. This keeps `ARGV.last(n)` reliable: `n` never changes for a
   given script.

2. **`database_path` is always first** among *our own* arguments -- i.e. the
   first element of the Python `args` list, and the first variable named in
   the Ruby destructuring line. (Established via `extract_simulation_results`,
   which uses `database_path, output_folder, sim_id = ARGV.last(3)`.)
   `list_simulations.rb` is consistent with this trivially, since it only
   ever sends one argument (`database_path`), so it's simultaneously first
   and last there.
   - Note this is about order *among our own arguments only*. It has nothing
     to do with `ARGV[0]` in the raw sense -- see Rule 3. The Autodesk build
     of `ICMExchange.exe` still prepends its own argument (observed as
     `"ADSK"`) *before* anything we send, so our own arguments are only ever
     guaranteed to be contiguous **at the end** of the real `ARGV`, regardless
     of which of *our* arguments comes conceptually "first."

3. **Ruby always reads with `ARGV.last(n)`, never `ARGV[0]`.** `n` = however
   many arguments *this specific script* expects. `ARGV.last(n)` preserves the
   original left-to-right order of whatever was sent -- it does **not**
   reverse anything, it just takes the trailing `n` elements.

4. **Every script documents its own argument contract** in a comment at the
   very top of the `.rb` file, and the corresponding Python method's `args =
   [...]` line should be built in that exact order, ideally right next to a
   comment referencing this doc.

5. **When debugging an argument-order issue**, add this line to the very top
   of the script temporarily:
   ```ruby
   puts "ARGV received: #{ARGV.inspect}"
   ```
   Compare what it prints against the Python `args = [...]` line, position by
   position. Remove the line once confirmed.

## Script reference table

| Script (`.rb`) | Python method | Argument order (positions, left to right) | Notes |
|---|---|---|---|
| `list_simulations.rb` | `ICMSession.list_simulations()` | `[database_path]` | Only 1 arg; `database_path` is both first and last here since it's the only one. |
| `extract_simulation_results.rb` | `ICMSession.extract_simulation_results(sim)` | `[database_path, output_folder, sim_id]` | Confirmed matching on both sides. Diagnostic `ARGV.inspect` line still present in the script as of last check -- remove once a successful real-model run is confirmed. |

## Checklist for adding a new script

- [ ] Decide the argument list, in order, ending with `database_path` last.
- [ ] Write the Ruby destructuring line as `arg1, arg2, ..., database_path = ARGV.last(n)`, matching that order exactly.
- [ ] Add a one-line comment at the top of the `.rb` file stating the expected argument order.
- [ ] Write the Python method's `args = [...]` line in that same order, with a comment referencing this doc.
- [ ] Add a row to the table above.
- [ ] Test once with the `ARGV.inspect` diagnostic line before removing it.
- [ ] If any argument is optional, use `""` (or another documented placeholder) rather than omitting it -- never change the argument count based on which values are present.

## Known gotchas encountered so far

- **`ARGV[0]` is not reliable** with the Autodesk-licensed `ICMExchange.exe` --
  it prepends its own argument (`"ADSK"`) ahead of anything sent from Python.
  Always anchor to the end (`ARGV.last(n)` / `ARGV[-1]`), never the start.
- **`ARGV.last(n)` does not reverse order** -- it's the trailing `n` elements,
  in their original order, same as Python's `list[-n:]`.
- **Everything in `ARGV` arrives as a string**, regardless of what type it
  logically is -- e.g. `sim_id` needs `.to_i` in Ruby before being passed to
  methods like `model_object_from_type_and_id` that expect a real integer.
