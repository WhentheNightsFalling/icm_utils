# ICM Exchange Package: Architecture & Reference

See also: `argument_convention.md` for the Python↔Ruby argument-ordering rules.

## Architecture overview

Five pieces, each with one job:

```
ICMConfig        -- installation-level settings (exchange_path, product, timeout_s)
Simulation        -- pure data: one row of "what simulations exist"
ScriptLibrary      -- internal-only: given a script name, find its .rb file on disk
ExchangeRunner      -- database-agnostic: run any script + args via subprocess, return result
ICMSession        -- public facade: owns database_path, wires the above together,
                       exposes the actual methods a caller uses
```

**Why split this way** (the reasoning, not just the shape):

- `ICMConfig` vs `ICMSession.database_path`: installation-level facts (where ICM
  lives on disk) don't change per task; which database you're working with
  does. Keeping them separate means one `ICMConfig` can back many
  `ICMSession`s, each pointed at a different `.icmm` file (or workgroup
  connection string -- `database_path` is typed as `str`, so
  `"myserver:40000/mydb"` works exactly the same as a local path, no code
  changes needed).
- `ExchangeRunner` knows nothing about databases, sim IDs, or ICM concepts at
  all -- its only job is "build a command list from a script path + args, run
  it, hand back the result." This is what makes it independently testable
  and reusable regardless of what a given script's arguments mean.
- `ICMSession` is where ICM-specific policy lives: "every script I run needs
  `database_path` appended," "here's how to find a script by name," "here's
  what `list_simulations` means as an operation." It composes `ScriptLibrary`
  and `ExchangeRunner` rather than reimplementing either.
- `Simulation` is a plain `@dataclass`, deliberately **not** given methods
  like `.extract_results()` (the Active Record pattern). Reasoning: doing so
  would require every `Simulation` to carry a live reference back to a
  session, which breaks cleanly working with multiple sessions/databases at
  once, and complicates testing (every `Simulation` test would need a real or
  fake session, not just plain values). Instead, `ICMSession` methods take a
  `Simulation` (or its `.id`) as a plain parameter -- `session.
  extract_simulation_results(sim)`, not `sim.extract_results()`. This also
  means `Simulation` objects can be constructed and compared in tests with no
  ICM connection at all.

## `ICMConfig`

```python
@dataclass
class ICMConfig:
    exchange_path: Path
    product: str = "ICM"
    timeout_s: int = 300
```

Installation-level settings. `@dataclass` auto-generates `__init__`,
`__repr__`, and `__eq__` from these three field annotations.

- `exchange_path` -- full path to the Exchange executable (e.g.
  `ICMExchange.exe`).
- `product` -- app code passed to the executable (`"ICM"` / `"IA"` / `"WS"`
  per the generic `IExchange` convention). **Known gap:** the
  Autodesk-licensed `ICMExchange.exe` build actually in use doesn't require
  or read this argument at all (see Appendix 10 in the Exchange docs, and
  `argument_convention.md`'s gotchas) -- it's currently sent anyway, unused,
  kept intentionally in case a future `ICMConfig` points at a different
  Exchange build that does need it.
- `timeout_s` -- **not currently used anywhere.** `ExchangeRunner.run_script`
  calls `subprocess.run(...)` without a `timeout=` argument at all, so a
  hung script would currently block forever rather than raising after
  `timeout_s` seconds. TODO.

## `Simulation`

```python
@dataclass
class Simulation:
    id: str
    run_name: str
    sim_name: str
    path: str
    status: str
```

Pure data, one instance per simulation in a database. Field order matters:
it must match the order `list_simulations.rb`'s `puts` line emits values in,
since `ICMSession.list_simulations()` constructs these positionally from
split stdout lines. Currently: `id|run_name|sim_name|path|status`.

- `path` is kept specifically to disambiguate simulations whose `run_name` +
  `sim_name` combination collides across different model groups (a real
  scenario the original design anticipated).
- All fields are `str` -- everything arriving from Ruby's `ARGV`/`puts` is
  text; no type coercion happens on the Python side currently (e.g. `id`
  stays a string, isn't cast to `int`).

## `ScriptLibrary`

```python
class ScriptLibrary:
    def __init__(self):
        self.script_dir = Path(__file__).parent / "ruby_scripts"

    def get_script_path(self, script_name: str) -> Path:
        return self.script_dir / f"{script_name}.rb"
```

Locates bundled `.rb` scripts. Uses `Path(__file__).parent` so script
resolution works correctly regardless of the caller's current working
directory -- required for this to work once pip-installed into
`site-packages/` somewhere arbitrary.

**Deliberately internal-only / not defensive:** `get_script_path` always
appends `.rb` -- passing a name that already ends in `.rb` produces a broken
`name.rb.rb` path, with no guard against it. This is intentional: this class
is only ever called from `ICMSession`'s own methods, which the developer
fully controls, so there's no untrusted input to defend against. **Not
suitable to expose as a public/user-facing API without adding that guard.**

**Known gap:** no support yet for user-supplied script search paths (custom
scripts outside the package) -- deferred until an actual need arises, per
project convention of not building for hypothetical future requirements.

## `ExchangeRunner`

```python
class ExchangeRunner:
    def __init__(self, config: ICMConfig):
        self.config = config

    def run_script(self, script_path: Path, args=None):
        if args is None:
            args = []
        return subprocess.run(
            [self.config.exchange_path, script_path, self.config.product, *args],
            capture_output=True, text=True
        )
```

Database-agnostic subprocess wrapper. Command shape:
`[exchange_path, script_path, product, *args]`. `args` defaults to `None`
rather than `[]` to avoid Python's mutable-default-argument trap (a `[]`
default would be created once and shared/mutated across every call that
omits `args`).

**Known gaps:**
- Does not check `result.returncode`. A failed script (bad Ruby, missing
  file, etc.) currently returns a normal-looking `CompletedProcess` with a
  non-zero `returncode` -- nothing raises or flags this. Caller must check
  `.returncode`/`.stderr` manually.
- Does not pass `timeout=self.config.timeout_s` to `subprocess.run` -- see
  `ICMConfig` note above.
- Neither of these block current usage but are the natural next hardening
  step (this maps to the previously-discussed `ExchangeError`/
  `ExchangeRunError`/`ExchangeTimeoutError` idea -- not yet implemented in
  the current code).

## `ICMSession`

```python
class ICMSession:
    def __init__(self, config: ICMConfig, database_path: str):
        self.config = config
        self.database_path = database_path
        self.exchange_runner = ExchangeRunner(config)
        self.scripts = ScriptLibrary()
```

Public facade. Owns `database_path` (task-level, deliberately kept out of
`ExchangeRunner` -- see architecture reasoning above) and composes an
`ExchangeRunner` + `ScriptLibrary` internally.

### `list_simulations()` -> `list[Simulation]`

Runs `list_simulations.rb` with `args=[self.database_path]` (only argument
this script needs). Parses each line of stdout (`id|run_name|sim_name|path|
status`) into a `Simulation`, returns them as a list. **Working, tested
against a real model.**

Corresponding Ruby (`list_simulations.rb`):
```ruby
db = WSApplication.open ARGV[-1]
sims = db.model_object_collection('Sim')
sims.each do |sim|
  run = db.model_object_from_type_and_id(sim.parent_type, sim.parent_id)
  puts "#{sim.id}|#{run.name}|#{sim.name}|#{sim.path}|#{sim.status}"
end
```

### `sims_to_dict()` -> `dict[str, Simulation]`

Builds a `run_name_sim_name`-keyed dict from `list_simulations()`, intended
to append `_<count>` to any key that collides, so no simulation is silently
dropped/overwritten (the original design concern -- see `list_simulations`
docstring above re: `path` existing for the same reason).

**⚠️ Known behavioral quirk, worth checking before relying on this in
calibration work:** the current implementation mutates `keys[i]` in place
inside a loop that re-evaluates `keys.count(keys[i])` against the
*already-partially-mutated* list. Traced through with 3 identical duplicate
keys, the actual output is inconsistent suffixing (e.g. `_3`, `_2`, then the
*last* duplicate left with **no suffix at all** rather than every duplicate
being clearly numbered `_1` through `_n` as intended). It does not lose data
(every key ends up unique), but the naming pattern doesn't match the
"1, 2, 3, 4, 5" scheme originally described. Recommend revisiting with the
two-pass approach (count everything first via `collections.Counter` on a
separate list, *then* build the dict, so no key's count depends on
already-mutated state) if consistent numbering matters for how you'll
actually use these keys.

### `extract_simulation_results(sim: Simulation)` -- **in progress, currently has a known bug**

```python
def extract_simulation_results(self, sim: Simulation):
    temp = tempfile.mkdtemp()
    args = [self.database_path, temp, sim.id]
    script_path = self.scripts.get_script_path("extract_simulation_results")
    ruby_output = self.exchange_runner.run_script(script_path, args)
    print(ruby_output.stdout)
```

**✅ Argument order confirmed fixed.** Ruby now reads
`database_path, output_folder, sim_id = ARGV.last(3)`, matching Python's
`args = [self.database_path, temp, sim.id]` position-for-position. This also
settled the project-wide convention (see `argument_convention.md` Rule 2,
updated accordingly): **`database_path` goes first** among a script's own
arguments, not last as originally drafted. `list_simulations.rb` remains
consistent with this trivially, since it only ever sends one argument.

**Still open:**
- The Ruby script still contains a temporary diagnostic line
  (`puts "ARGV received: #{ARGV.inspect}"`) added while debugging the order
  mismatch -- remove once a successful real-model run is confirmed.
- Not yet confirmed whether the export actually succeeds end-to-end against
  a real model (produces a real CSV in `output_folder`).

**Also not yet implemented:** creates a temp folder, calls the export
script, and currently just `print()`s the raw Ruby stdout. Does not yet:
- Read the resulting CSV file(s) with `pandas`
- Return a `DataFrame`
- Handle the possibility of `results_csv_export` producing multiple files

Target design (per prior discussion): the export uses `nil` selection
(whole network) and all attributes for v1 -- selection/attribute narrowing
for large (e.g. 30-year) runs is an intentionally deferred increment, not
yet built.

## Current TODO list (as of last update)

**ICM Modeling Core:**
- Retrieving simulation results -- specifying element, specifying specific
  results (flow/depth/velocity) -- *(in progress, see
  `extract_simulation_results` above)*
- Listing networks
- Scenario listing and switching
- Retrieving network elements: nodes, links, subcatchments
- Editing network elements: nodes, links, subcatchments

**Model Calibration Toolkit:**
- Observed vs. simulated comparison (peak flows, flow volumes, time to peak)
- Event identification (simple thresholding, user-defined threshold +
  interevent time)

**Package infrastructure** (from earlier discussion, not yet started):
- Raise `ExchangeRunError`/`ExchangeTimeoutError` instead of silently
  returning failed `CompletedProcess` results
- Wire `ICMConfig.timeout_s` into `subprocess.run`
- Ensure `ruby_scripts/` is actually bundled into the pip package
  (`package_data`/`MANIFEST.in` -- non-`.py` files are not included by
  default)
- Unit tests for pure-Python pieces (`ScriptLibrary` path resolution,
  stdout parsing, `sims_to_dict`) that don't require a real ICM install
- Fix `sims_to_dict`'s inconsistent-suffix quirk (see above)
- README + minimal usage example
